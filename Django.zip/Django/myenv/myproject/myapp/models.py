from django.db import models

# Create your models here.
class News(models.Model):
    Title=models.CharField(max_length=100)
    category=models.CharField(max_length=50)
    Date=models.DateField()
    Description=models.TextField(null=True)
   
    Image=models.ImageField(null=True,blank=True,upload_to='media/')
    
    def __str__(self):
        return self.Title
   