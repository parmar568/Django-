from django.shortcuts import render,redirect
from myapp.models import *
import datetime
from myapp import models

def index(request):
    request.method="post"
    info=News.objects.all()
    return render(request,'index.html',{'info':info})

def add(request):
    if request.method=="POST":
        Title=request.POST.get('Title')
        category=request.POST.get('category')
        Date=request.POST.get('Date')
        description=request.POST.get('Description')
      
        image=request.FILES['image']

        print(image)
        News.objects.create(
            Title=Title,
            category=category,
            Date=Date,
            Description=description,
            
            Image=image
           )
        return redirect('home')
    return render(request,'index.html')

def update(request,id):
    if request.method=="POST":
        Title=request.POST.get('Title')
        category=request.POST.get('category')
        date=datetime.date.today()
        description=request.POST.get('Description')
        image=request.FILES['image']
        
        info=News(
            id=id,
            Title=Title,
            category=category,
            Date=date,
            Description=description,
            Image=image
        )
        info.save()
        return redirect('home')
    return render(request,'index.html')

def delete(request,id):
    info=News.objects.filter(id=id)
    info.delete()
    return redirect('home')
    
   
        